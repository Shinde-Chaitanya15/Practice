$(document).ready(function(){
  $('.slider').slide({
arrows:false,
dots:true,
appendDots:'.Slider-dots',
dotsClass:'dots'
  });
});
